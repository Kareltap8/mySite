

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.DqfQ_vMb.js","_app/immutable/chunks/scheduler.Bmg8oFKD.js","_app/immutable/chunks/index.CJxSZ2Uz.js","_app/immutable/chunks/stores.D-fBJ9g-.js","_app/immutable/chunks/entry.C8ZrFJ5n.js"];
export const stylesheets = [];
export const fonts = [];

import{a as t}from"../chunks/entry.C8ZrFJ5n.js";export{t as start};
